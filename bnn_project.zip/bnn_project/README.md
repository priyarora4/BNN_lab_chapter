
# Binary Neural Network Project 

```
├── bnn_project 
│   ├── hls ==> this folder contains hls testbenches     
│   │   ├── **/*.cpp
│   ├── python ==> this folder dataset, weights and python reference implementation     
│   │	├── dataset
│	│	├── weights
│	│	├── bnn_mnist.py		 	
├── README.md 
└── .gitignore
```

 

